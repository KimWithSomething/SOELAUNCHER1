--------------------------------------------------------------------------------------------------------------------
usa_east_transport = Company:new{ name = "USA East Transport", money = 10000000, is_transport = true }
Company:register(usa_east_transport)
andes_transport = Company:new{ name = "Andes Transport", money = 10000000, is_transport = true }
Company:register(andes_transport)
mexico_transport = Company:new{ name = "Mexico Transport", money = 10000000, is_transport = true }
Company:register(mexico_transport)
royal_russia_transport = Company:new{ name = "Royal Russia Transport", money = 10000000, is_transport = true }
Company:register(mexico_transport)
british_india_company = Company:new{ name = "British India Company", money = 10000000, is_transport = true }
Company:register(british_india_company)
--------------------------------------------------------------------------------------------------------------------