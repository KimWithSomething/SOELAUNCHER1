communism = Ideology:new{ ref_name = "communism", name = _("Communism"), check_policies_fn = "?" }
Ideology:register(communism)

democracy = Ideology:new{ ref_name = "democracy", name = _("Democracy"), check_policies_fn = "?" }
Ideology:register(democracy)

facism = Ideology:new{ ref_name = "facism", name = _("Facism"), check_policies_fn = "?" }
Ideology:register(facism)

socialism = Ideology:new{ ref_name = "socialism", name = _("Socialism"), check_policies_fn = "?" }
Ideology:register(socialism)

republic = Ideology:new{ ref_name = "republic", name = _("Republic"), check_policies_fn = "?" }
Ideology:register(republic)

tribal = Ideology:new{ ref_name = "tribal", name = _("Tribal"), check_policies_fn = "?" }
Ideology:register(tribal)

monarchy = Ideology:new{ ref_name = "monarchy", name = _("Monarchy"), check_policies_fn = "?" }
Ideology:register(monarchy)

anarchy = Ideology:new{ ref_name = "anarchy", name = _("Anarchy"), check_policies_fn = "?" }
Ideology:register(anarchy)

anarcho_capitalism = Ideology:new{ ref_name = "anarcho_capitalism", name = _("Anarcho-Capitalism"), check_policies_fn = "?" }
Ideology:register(anarcho_capitalism)

corporatocracy = Ideology:new{ ref_name = "corporatocracy", name = _("Corporatocracy"), check_policies_fn = "?" }
Ideology:register(corporatocracy)

enviromentalism = Ideology:new{ ref_name = "enviromentalism", name = _("Enviromentalism"), check_policies_fn = "?" }
Ideology:register(enviromentalism)

authoritarian = Ideology:new{ ref_name = "authoritarian", name = _("Authoritarian"), check_policies_fn = "?" }
Ideology:register(authoritarian)

progressivism = Ideology:new{ ref_name = "progressivism", name = _("Progressivism"), check_policies_fn = "?" }
Ideology:register(progressivism)

secularism = Ideology:new{ ref_name = "secularism", name = _("Secularism"), check_policies_fn = "?" }
Ideology:register(secularism)