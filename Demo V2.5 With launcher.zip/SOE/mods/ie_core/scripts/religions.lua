-- Religion
protestant = Religion:new{ ref_name = "protestant" }
protestant.name = _("Protestant")
Religion:register(protestant)

catholic = Religion:new{ ref_name = "catholic" }
catholic.name = _("Catholic")
Religion:register(catholic)

orthodox = Religion:new{ ref_name = "orthodox" }
orthodox.name = _("Orthodox")
Religion:register(orthodox)

islamic = Religion:new{ ref_name = "islamic" }
islamic.name = _("Islamic")
Religion:register(islamic)

buddhist = Religion:new{ ref_name = "buddhist" }
buddhist.name = _("Buddhist")
Religion:register(buddhist)

animist = Religion:new{ ref_name = "animist" }
animist.name = _("Animist")
Religion:register(animist)